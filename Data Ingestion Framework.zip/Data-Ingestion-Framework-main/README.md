# UCI RAG with GPT-3.5 Turbo
## Setup Instructions
1. Clone this repository
2. Create a virtual environment: python -m venv .venv
3. Activate it:
- Windows: `.\.venv\Scripts\activate`
- Mac/Linux: `source .venv/bin/activate`
4. Install dependencies: pip install -r requirements.txt
5. Run the script: python main.py







